import add_one

print("Start program")
add_one(2)
